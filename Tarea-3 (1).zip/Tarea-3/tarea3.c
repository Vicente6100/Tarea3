#include <stdio.h>
#include <stdlib.h>
#include <stdbool.h>
#include "tdas/list.h"
#include "tdas/heap.h"
#include "tdas/extra.h"
#include <string.h>
//Maximo en caso de querer introducir un laberinto mayor al del ejemplo
#define MAX 100 
#define TIEMPO 10

// Definición de la estructura para los Items
typedef struct {
    char Nombre[50] ;
    int puntaje ;
    int peso ;
    int enSala ; // 1 si está en la sala, 0 si está en el inventario o fue descartado.
} Item;
//Def de estructura para el Escenario
typedef struct Escenario{
    int id ;
    char lugar[50] ;
    char desc[300] ;
    List * items ; // objetos que hay en el escenario
    struct Escenario *arriba ;
    struct Escenario *abajo ;
    struct Escenario *izq ;
    struct Escenario *der ;
    int esFinal ;  // 1 si es la ultima sala
} Escenario ;
//Def de estructura para el jugador
typedef struct{
    Escenario *posicion ;
    List *inventario ;
    int peso ;
    int puntaje ;
    int tiempoRestante ; 
}Jugador ;

//////////////////           Mostrar           //////////////////

//Todas estas funciones hacen lo que dice su nombre

void mostrarMenuPrincipal() {
  limpiarPantalla();
  puts("========================================");
  puts("    Graph Quest");
  puts("========================================");

  puts("1) Cargar Laberinto");
  puts("2) Iniciar la Partida");
  puts("3) Salir") ;
}
void mostrarOpciones(){
    puts("1) Recoger objeto(s)");
    puts("2) Descartar objeto(s)");
    puts("3) Moverse de habitación") ;
    puts("4) Reiniciar partida");
    puts("5) Salir del juego");

}
void mostrarDireccion(){
    puts("1) Moverse a la habitación de Arriba");
    puts("2) Moverse a la habitación de Abajo");
    puts("3) Moverse a la habitación de la Izquierda") ;
    puts("4) Moverse a la habitación de la Derecha");
}
int mostrarObjetos(List *lista){
    int n = 0 ;
    for (Item *objeto = list_first(lista); objeto != NULL; objeto = list_next(lista)){
        if(objeto->enSala == 0) continue ;
        n++ ;
        printf(" %d) %s (peso: %d kg, valor: %d pts)\n", n, objeto->Nombre, objeto->peso, objeto->puntaje) ;
    }
    if (n == 0) printf("No hay objetos en la habitación\n") ;
    return n ;
}
int mostrarInventario(Jugador *p){
    int n = 0 ;
    for (Item *objeto =list_first(p->inventario); objeto != NULL; objeto = list_next(p->inventario)){
        n++ ;
        printf(" %d) %s (peso: %d kg, valor: %d pts)\n", n, objeto->Nombre, objeto->peso, objeto->puntaje) ;
    }
    if (n == 0) printf("El inventario está vacío\n") ;
    printf(" Peso total en el inventario : %d kg \n Puntaje total acumulado: %d pts\n", p->peso, p->puntaje) ;
    return n ;
}    
void mostrarEstado(Jugador *p){
    Escenario *habitacion = p->posicion ;
    limpiarPantalla() ;
    puts("------------------------") ;
    printf(" %s\n", habitacion->lugar) ;
    puts("------------------------") ;
    printf(" %s\n\n", habitacion->desc) ;

    puts("Objetos disponibles en la Sala") ;
    mostrarObjetos(habitacion->items) ;

    printf("\nTiempo restante : %d\n", p->tiempoRestante > 0 ? p->tiempoRestante : 0) ;
    puts("\nInventario:") ;
    mostrarInventario(p) ;

    puts("\nDirecciones posibles:") ;
    if (habitacion->arriba) puts("  Arriba") ;
    if (habitacion->abajo)  puts("  Abajo") ;
    if (habitacion->izq)    puts("  Izquierda") ;
    if (habitacion->der)    puts("  Derecha") ;
    printf("\n") ;

}

///////////////////           carga           ///////////////////

Escenario *habitacionProxima(Escenario *laberinto[], int id){
    //verifica si una habitacion es continua a otra
    if(id < 0 || id>= MAX) return NULL ;
    return laberinto[id] ;
}

//intenta cargar el archivo del laberinto
int cargarLaberinto(Escenario *laberinto[]){
    //carga un laberinto desde la direccion .csv especificada
    getchar() ;
    char ruta[256] ;
    puts("Ingrese la ruta del archivo") ;
    scanf("%255[^\n]", ruta) ;
    FILE *archivo = fopen(ruta, "r") ;
    if(archivo == NULL){
        perror("Error al abrir el archivo") ; //informa si hubo un error al abrir el archivo
        return 0;
    }

    char **campos ;
    campos = leer_linea_csv(archivo, ',') ;
    int proximas[MAX][4] ; // habitaciones proximas [Maximo de escenarios] [arriba, abajo, izquierda o derecha]
    while((campos = leer_linea_csv(archivo, ',')) != NULL){
        int n = 0 ;
        while(campos[n] != NULL) n++ ;
        //verifica si hay algun campo vacio (habitacion sin objetos por ejemplo)
        if (n == 8){
            for(int k = 8 ; k>3; k--) campos[k] = campos[k-1] ;
            campos[3] = "" ;
            campos[9] = NULL ;
            n = 9 ;
        }
        if (n < 9) continue ;
        int id = atoi(campos[0]) ;
        
        if (id < 0 || id>=MAX) continue ;
        Escenario *habitacion = malloc(sizeof(Escenario)) ;
        habitacion->id = id;
        strncpy(habitacion->lugar, campos[1], sizeof(habitacion->lugar) -1 ) ;
        habitacion->lugar[sizeof(habitacion->lugar)-1] = '\0' ;
        strncpy(habitacion->desc, campos[2], sizeof(habitacion->desc) -1) ;
        habitacion->desc[sizeof(habitacion->desc) -1 ] = '\0';
        habitacion->items = list_create() ;

        //Lee los objetos en la Sala
        if(strlen(campos[3]) > 0){
            List *lista_objetos = split_string(campos[3], ";") ;
            for(char *txt = list_first(lista_objetos) ; txt != NULL ; txt = list_next(lista_objetos)){
                List *info = split_string(txt, ",") ;
                char *Nombre = list_first(info ) ;
                char *puntaje = list_next(info) ;
                char *peso = list_next(info) ;
                if (Nombre == NULL || puntaje == NULL || peso ==NULL) continue ;
                
                Item *objeto = malloc(sizeof(Item)) ;
                strncpy(objeto->Nombre, Nombre, sizeof(objeto->Nombre)- 1) ;
                objeto->Nombre[sizeof(objeto->Nombre)-1] = '\0' ;
                objeto->puntaje = atoi(puntaje) ;
                objeto->peso = atoi(peso) ;
                objeto->enSala = 1 ;
                list_pushBack(habitacion->items, objeto) ;
            }
            
        }

        proximas[id][0] = atoi(campos[4]) ; //arriba
        proximas[id][1] = atoi(campos[5]) ; //abajo
        proximas[id][2] = atoi(campos[6]) ; //izq
        proximas[id][3] = atoi(campos[7]) ; //der

        habitacion->esFinal = (strcmp(campos[8], "Si") == 0) ; 
        laberinto[id] = habitacion ;
        
    }
    fclose(archivo) ;

    for(int i = 0; i < MAX; i++){
        Escenario *habitacion = laberinto[i] ;
        if(habitacion == NULL) continue ;
        habitacion->arriba = habitacionProxima(laberinto, proximas[i][0]) ;
        habitacion->abajo = habitacionProxima(laberinto, proximas[i][1]) ;
        habitacion->izq = habitacionProxima(laberinto, proximas[i][2]) ;
        habitacion->der = habitacionProxima(laberinto, proximas[i][3]) ;
    }

    puts("Laberinto cargado con éxito") ;
    return 1;
}

//////////////////           Partida           //////////////////
void recogerItem(Jugador *p){
    //añade un objeto de la sala al inventario
    while(true){
        puts("\nObjetos disponibles en la Sala:") ;
        if(mostrarObjetos(p->posicion->items) == 0) return ;
        puts("Seleccione el objeto a recoger (0 para no recoger ningun objeto de la Sala)") ;
        char opcion ;
        scanf(" %c", &opcion) ;
        if(opcion == '0') return ;

        int n = 0 ;
        Item *seleccionado = NULL ;
        for (Item *objeto = list_first(p->posicion->items); objeto != NULL ; objeto = list_next(p->posicion->items)){
            if (objeto->enSala == 0) continue ;
            n++ ;
            if (n== opcion - '0') { //Se utiliza para obtener el valor entero del caracter
                seleccionado = objeto ;
                break ;
            }
        }
        if (seleccionado == NULL){
            puts("Opcion no válida") ;
            continue ;
        }
            
    seleccionado->enSala = 0 ;
    list_pushBack(p->inventario, seleccionado) ;
    p->peso += seleccionado->peso ;
    p->puntaje += seleccionado->puntaje ;
    p->tiempoRestante -= 1 ;
    printf("Has recogido <<%s>> \n", seleccionado->Nombre ) ;

    if(p->tiempoRestante <= 0) return ;
    }
}

void descartarItem(Jugador *p){
    //Elimina un objeto del inventario y resta el peso y el puntaje asociado
    while(true){
        puts("\nInventario") ;
        if(mostrarInventario(p)== 0) return ;
        puts("Seleccione el objeto a descartar (0 para no descartar ninguno)") ;
        char opcion ;
        scanf(" %c", &opcion) ;
        if(opcion == '0') return ;

        int n = 0 ;
        Item *seleccionado = NULL ;
        for (Item *objeto = list_first(p->inventario); objeto != NULL ; objeto = list_next(p->inventario)){
            n++ ;
            if (n== opcion - '0') { //Se utiliza para obtener el valor entero del caracter
                seleccionado = objeto ;
                list_popCurrent(p->inventario) ;
                break ;
            }
        }
        if (seleccionado == NULL){
            puts("Opcion no válida") ;
            continue ;
        }

    p->peso -= seleccionado->peso ;
    p->puntaje -= seleccionado->puntaje ;
    p->tiempoRestante -= 1 ;
    printf("Has descartado <<%s>> \n", seleccionado->Nombre ) ;

    if(p->tiempoRestante <= 0) return ;
    }
}

int avanzar(Jugador *p){
    //Muestra las direcciones disponibles y solicita una opcion para ejecutar el desplazamiento ;
    mostrarDireccion() ;
    char direccion ;
    scanf(" %c", &direccion) ;

    Escenario *habitacion = p->posicion ;
    Escenario *habitacionSgte = NULL ;
    switch (direccion) {
        case '1':
            habitacionSgte = habitacion->arriba ;
            break;
        case '2':
            habitacionSgte = habitacion->abajo ;
            break;
        case '3' :
            habitacionSgte = habitacion->izq ;    
            break ;
        case '4' :
            habitacionSgte = habitacion->der ;    
            break ;
        default:
            puts("Movimiento invalido.");            
        }
    if(habitacionSgte == NULL){
        puts("No puedes avanzar en esa direccion") ;
        return 0 ;
    }
    
    int pesoTotal = p->peso + 1 ;  
    int costeTiempo = pesoTotal / 10 ;
    if(pesoTotal % 10 != 0) costeTiempo ++ ;
    
    p->tiempoRestante -= costeTiempo ;
    p->posicion = habitacionSgte ;
    return 1 ;
}

void reiniciar(Jugador *p, Escenario *laberinto[]){
    //reinicia la partida desde el punto de inicio
    while(list_first(p->inventario) != NULL) list_popCurrent(p->inventario) ;
    for (int i = 0; i < MAX; i++){
        if (laberinto[i] == NULL) continue ;
        for (Item *objetos = list_first(laberinto[i]->items); objetos != NULL; objetos = list_next(laberinto[i]->items)) objetos->enSala = 1 ;
    }
    p->posicion = laberinto[1] ;
    p->peso = 0 ;
    p->puntaje = 0 ;
    p->tiempoRestante = TIEMPO ;
}

int revisarFinal(Jugador *p){
    //Verifica el estado final de la partida
    if(p->posicion->esFinal && p->tiempoRestante >= 0){
        printf("\n") ;
        puts("¡Llegaste al final con éxito!");
        puts("Resumen del inventario :") ;
        mostrarInventario(p) ;
        printf("Puntaje final: %d\n", p->puntaje) ;
        puts("Juego Terminado") ;
        return 1;
    }
    if(p->tiempoRestante <= 0){
        puts("DERROTA") ;
        puts("No lograste llegar en el tiempo disponible. ¡Vuelve a intentarlo!") ;
        return 1 ;
    }
    return 0 ;
}

int IniciarPartida(Escenario *laberinto[]){
    puts("Partida iniciada");
    Jugador p;
    p.inventario = list_create() ;
    reiniciar(&p, laberinto) ;
    char opcion ;
    
    do {
        mostrarEstado(&p) ;
        mostrarOpciones() ;
        
        printf("Ingrese su opcion: ") ;
        scanf(" %c", &opcion) ;
        int movimiento = 0;
        
        switch (opcion) {
        case '1':
            recogerItem(&p) ;
            break;
        case '2':
            descartarItem(&p) ;
            break;
        case '3' :
            movimiento = avanzar(&p) ;
            break ;
        case '4' :
            reiniciar(&p, laberinto) ;
            puts("Partida reiniciada.") ;
            break ;
        case '5' :
            break ;
        default:
             puts("Opción no válida. Por favor, intente de nuevo.");            
        }

        if (revisarFinal(&p)) return 0 ;
        if (opcion != '3' || !movimiento) presioneTeclaParaContinuar();
        limpiarPantalla();
        
      } while (opcion != '5') ;
    return 1 ;
    
}

//////////////////            Main             //////////////////
int main() {  
    Escenario** laberinto = calloc(MAX, sizeof(Escenario*));
    if (laberinto == NULL){
        puts("Error: No se pudo reservar memoria");
        return 1 ;
    }
    
    char opcion;
    int carga = 0 ;
    do {
        mostrarMenuPrincipal();
        printf("Ingrese su opción: ");
        scanf(" %c", &opcion);
    
        switch (opcion) {
        case '1':
            carga = cargarLaberinto(laberinto) ;
            break;
        case '2':
            if(carga == 1) {
                if(IniciarPartida(laberinto) == 1) opcion = '3' ;
            }
            else{
                puts("El laberinto no ha sido cargado") ;
            }
            break;
        case '3' :
            puts("Saliendo del Menu Principal") ;    
            break ;
        default:
            puts("Opción no válida. Por favor, intente de nuevo.");            
        }
        presioneTeclaParaContinuar();


  } while (opcion != '3');

  free(laberinto) ;        
  return 0;
}
